package com.example.arshdeep.exam;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class PointsBoardActivity extends AppCompatActivity {
    TextView runsgivenperover,runsgivenperwicket,bowlingpoints;

    TextView strikerate,battingpoints;

    int temptotalruns=0,totaloverthrown=0,temptotalwickets=0,tempballplayed,temptotalfifty=0,temptotalhundred=0;
    int temprunsperover=0,temptotalrunsperwicket=0,tempstrikerate=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_points_board);

        runsgivenperover = (TextView) findViewById(R.id.last_runsgiven);
        runsgivenperwicket =(TextView) findViewById(R.id.last_runs_per_wickets);
        bowlingpoints = (TextView) findViewById(R.id.last_bowling_points_earned);

        strikerate = (TextView) findViewById(R.id.last_strike_rate);
        battingpoints = (TextView) findViewById(R.id.last_batting_points);

        SharedPreferences sharedPreferences = getSharedPreferences("com.example.arshdeep.exam", Context.MODE_PRIVATE);



        temptotalruns = Integer.parseInt(sharedPreferences.getString("RUNSGIVEN","Data Missing"));
        totaloverthrown = Integer.parseInt(sharedPreferences.getString("OVERTHROWN","Data Missing"));
        temptotalwickets = Integer.parseInt(sharedPreferences.getString("WICKETSTAKEN","Data Missing"));

        tempballplayed = Integer.parseInt(sharedPreferences.getString("BALLSPLAYED","Data Missing"));
        temptotalfifty = Integer.parseInt(sharedPreferences.getString("NOOFFIFTY","Data Missing"));
        temptotalhundred = Integer.parseInt(sharedPreferences.getString("NOOFHUNDRED","Data Missing"));


        temprunsperover = temptotalruns/totaloverthrown;
        temptotalrunsperwicket = temptotalruns/temptotalwickets;
        tempstrikerate = temptotalruns/tempballplayed;

        runsgivenperover.setText("RUNS PER OVER : "+ temprunsperover);
        runsgivenperwicket.setText("RUNS PER WICKET : "+ temptotalrunsperwicket);


        strikerate.setText("STRIKE RATE : "+ tempstrikerate);
        bowlingPoints();
        battingPoints();



    }
    public void bowlingPoints() {
        int bowlpoints=0;

        if (temprunsperover <3 ) {
            bowlpoints = (temptotalwickets*5)+10;
            bowlingpoints.setText("BOWLING POINTS : "+bowlpoints);
        }
        else {
            bowlpoints = (temptotalwickets*5)+5;
            bowlingpoints.setText("BOWLING POINTS : "+bowlpoints);
        }
    }
    public void battingPoints() {
        int batpoints=0;

        if (tempstrikerate > 80) {
            batpoints = (temptotalfifty*1)+(temptotalhundred*2) +10;
            battingpoints.setText("BATTING POINTS : "+batpoints);
        }
        else {
            batpoints = (temptotalfifty*1)+(temptotalhundred*2) +3;
            battingpoints.setText("BATTING POINTS : "+batpoints);
        }

    }




}
