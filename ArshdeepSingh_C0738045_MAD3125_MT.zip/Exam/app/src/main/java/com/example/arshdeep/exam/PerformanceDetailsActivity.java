package com.example.arshdeep.exam;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class PerformanceDetailsActivity extends AppCompatActivity {
    TextView uId,uName;
    EditText overThrown,runsGiven,wicketsTaken;

    EditText ballsPlayed,runsScored,noOfFifty,noOfHundred;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_performance_details);
        uId =(TextView) findViewById(R.id.text_view_id);
        uName = (TextView) findViewById(R.id.text_view_name);

        overThrown = (EditText) findViewById(R.id.performance_overs);
        runsGiven = (EditText) findViewById(R.id.performance_runs);
        wicketsTaken = (EditText) findViewById(R.id.performance_wickets);
        ballsPlayed = (EditText) findViewById(R.id.performance_balls_played);
        runsScored = (EditText) findViewById(R.id.performance_runs_scored);
        noOfFifty = (EditText) findViewById(R.id.performance_50);
        noOfHundred = (EditText) findViewById(R.id.performance_100);

        SharedPreferences sharedPreferences =getSharedPreferences("com.example.arshdeep.exam", Context.MODE_PRIVATE);
        uId.setText("User ID : "+sharedPreferences.getString("USERID","Data Missing"));
        uName.setText("User Name : "+sharedPreferences.getString("USERNAME","Data Missing"));

    }
    public void onNext(View view) {
        if (overThrown.getText().toString().length()==0) {
            overThrown.setError("Compulsory Field");
        }
        else if (runsGiven.getText().toString().length()==0) {
            runsGiven.setError("Compulsory Field");
        }
        else if (wicketsTaken.getText().toString().length()==0) {
            wicketsTaken.setError("Compulsory Field");
        }
        else if (ballsPlayed.getText().toString().length()==0) {
            ballsPlayed.setError("Compulsory Field");
        }
        else if (runsScored.getText().toString().length()==0) {
            runsScored.setError("Compulsory Field");
        }
        else if (noOfFifty.getText().toString().length()==0) {
            noOfFifty.setError("Compulsory Field");
        }
        else if (noOfHundred.getText().toString().length()==0) {
            noOfHundred.setError("Compulsory Field");
        }
        else{
            SharedPreferences sharedPreferences = getSharedPreferences("com.example.arshdeep.exam", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("OVERTHROWN", overThrown.getText().toString());
            editor.putString("RUNSGIVEN", runsGiven.getText().toString());
            editor.putString("WICKETSTAKEN", wicketsTaken.getText().toString());
            editor.putString("BALLSPLAYED", ballsPlayed.getText().toString());
            editor.putString("RUNSSCORED", runsScored.getText().toString());
            editor.putString("NOOFFIFTY", noOfFifty.getText().toString());
            editor.putString("NOOFHUNDRED", noOfHundred.getText().toString());
            editor.commit();
            startActivity(new Intent(this, PointsBoardActivity.class));
        }
    }
}
