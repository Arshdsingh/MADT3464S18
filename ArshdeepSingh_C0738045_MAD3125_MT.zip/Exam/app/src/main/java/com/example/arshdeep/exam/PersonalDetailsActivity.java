package com.example.arshdeep.exam;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;

public class PersonalDetailsActivity extends AppCompatActivity {
        EditText userid,username,matchplayed;

        RadioButton btnbowler,btnbatsman;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_details);

        userid = (EditText) findViewById(R.id.personal_id);
        username =(EditText) findViewById(R.id.personal_name);
        matchplayed = (EditText) findViewById(R.id.personal_match_played);
        btnbowler = (RadioButton) findViewById(R.id.radiobtn_bowler);
        btnbatsman = (RadioButton) findViewById(R.id.radiobtn_batsman);
    }
    public void onSubmit(View view) {
        if (userid.getText().toString().length()==0) {
            userid.setError("Compulsory Field");
        }
        else if (username.getText().toString().length()==0) {
            userid.setError("Compulsory Field");
        }
        else if (matchplayed.getText().toString().length()==0) {
            userid.setError("Compulsory Field");
        }
        else {
            SharedPreferences sharedPreferences = getSharedPreferences("com.example.arshdeep.exam", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("USERID", userid.getText().toString());
            editor.putString("USERNAME", username.getText().toString());
            editor.putString("MATCHPLAYED", matchplayed.getText().toString());
            editor.commit();
            startActivity(new Intent(this, PerformanceDetailsActivity.class));
        }
    }
}
